/** Automatically generated file. DO NOT MODIFY */
package hurdad.thoughtbox;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}